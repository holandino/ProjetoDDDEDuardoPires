namespace PaymentContext.Domain.Enums
{
    public enum EDocumentType
    {
        CPF = 1,
        CNPJ = 2
    }
}
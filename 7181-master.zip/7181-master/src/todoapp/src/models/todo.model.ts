export class Todo {
    constructor(
        public id: Number,
        public title: String,
        public done: Boolean,
    ) { }
}

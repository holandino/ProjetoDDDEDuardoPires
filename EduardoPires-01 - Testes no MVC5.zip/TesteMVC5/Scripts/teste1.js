/*!
 * Extensa documentacao blablabla
 *
 * Por Eduardo Pires
 */
function teste(parametro) {
    alert(parametro);
}
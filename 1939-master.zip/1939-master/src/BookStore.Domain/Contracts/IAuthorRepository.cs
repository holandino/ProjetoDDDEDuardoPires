﻿namespace BookStore.Domain.Contracts
{
    public interface IAuthorRepository : IRepository<Author>
    {
    }
}

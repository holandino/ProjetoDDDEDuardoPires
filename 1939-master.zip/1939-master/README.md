# 1939 - Uma visão completa do ASP.NET MVC #
Repositório do curso **Uma visão completa do ASP.NET MVC** da plataforma https://balta.io.

Autor: André Baltieri

Link: https://balta.io/cursos/1939

## Projeto construído com: ##
* C#
* ASP.NET MVC

---
balta.io - Develop Your Career

Conheça todos os cursos da plataforma em https://balta.io/cursos